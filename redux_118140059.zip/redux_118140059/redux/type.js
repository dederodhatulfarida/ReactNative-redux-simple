export const TAMBAH = 'TAMBAH'
export const KURANG = 'KURANG'

