import React from 'react';
import Calling from './Calling';

 const App = ()=>{
  return(
    <Calling/>
  );
}

export default App
